import os


from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	ExaSearchTool,
	ArxivPaperTool
)






@CrewBase
class MultiAgentHealthcareAssistantCrew:
    """MultiAgentHealthcareAssistant crew"""

    
    @agent
    def symptom_analyzer(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["symptom_analyzer"],
            
            
            tools=[				ExaSearchTool()],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def medical_researcher(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["medical_researcher"],
            
            
            tools=[				ArxivPaperTool()],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def appointment_scheduler(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["appointment_scheduler"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def insurance_advisor(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["insurance_advisor"],
            
            
            tools=[				ExaSearchTool()],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    
    @agent
    def medicine_reminder(self) -> Agent:
        
        
        return Agent(
            config=self.agents_config["medicine_reminder"],
            
            
            tools=[],
            
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4o-mini",
                
                
            ),
            
        )
        
    

    
    @task
    def analyze_patient_symptoms(self) -> Task:
        return Task(
            config=self.tasks_config["analyze_patient_symptoms"],
            markdown=False,
            
            
        )
    
    @task
    def research_medical_conditions(self) -> Task:
        return Task(
            config=self.tasks_config["research_medical_conditions"],
            markdown=False,
            
            
        )
    
    @task
    def schedule_appointment_guidance(self) -> Task:
        return Task(
            config=self.tasks_config["schedule_appointment_guidance"],
            markdown=False,
            
            
        )
    
    @task
    def insurance_coverage_guidance(self) -> Task:
        return Task(
            config=self.tasks_config["insurance_coverage_guidance"],
            markdown=False,
            
            
        )
    
    @task
    def create_medicine_reminder_plan(self) -> Task:
        return Task(
            config=self.tasks_config["create_medicine_reminder_plan"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the MultiAgentHealthcareAssistant crew"""

        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,

            chat_llm=LLM(model="openai/gpt-4o-mini"),
        )


